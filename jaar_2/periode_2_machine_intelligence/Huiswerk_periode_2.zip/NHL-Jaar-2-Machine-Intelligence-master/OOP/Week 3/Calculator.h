#pragma once


class Calculator {
public:
    std::string Calc(std::string imp);
};


