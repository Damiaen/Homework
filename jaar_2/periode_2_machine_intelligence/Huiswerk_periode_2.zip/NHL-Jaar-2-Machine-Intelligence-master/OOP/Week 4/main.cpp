#include <iostream>
#include <string>

using namespace std;

int main() {
    cout << "Type a number: " << endl;

    string dat;
    getline(cin, dat);


    cout << dat;
}
